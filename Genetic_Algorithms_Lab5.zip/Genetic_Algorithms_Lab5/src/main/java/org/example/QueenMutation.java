package org.example;

import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import java.util.List;
import java.util.Random;

public class QueenMutation implements EvolutionaryOperator<Integer[]> {
    private final Probability mutationProbability;
    private final int boardSize;

    public QueenMutation( int boardSize, Probability mutationProbability) {
        this.mutationProbability = mutationProbability;
        this.boardSize = boardSize;
    }

    @Override
    public List<Integer[]> apply(List<Integer[]> selectedCandidates, Random random) {
        for (Integer[] candidate : selectedCandidates) {
            if (random.nextDouble() < mutationProbability.doubleValue()) {
                // Perform mutation on the candidate solution.
                mutate(candidate, random);
            }
        }
        return selectedCandidates;
    }

    private void mutate(Integer[] candidate, Random random) {
        int rowIndex = random.nextInt(boardSize);
        int newColumnIndex = random.nextInt(boardSize + 1); // Add 1 to ensure values are between 0 and boardSize
        candidate[rowIndex] = newColumnIndex;
    }
}
