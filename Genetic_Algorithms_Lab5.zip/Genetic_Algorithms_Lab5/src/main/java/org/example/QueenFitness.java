
package org.example;

import org.uncommons.watchmaker.framework.FitnessEvaluator;

import java.util.List;

public class QueenFitness implements FitnessEvaluator<Integer[]> {
    // Don't change other parts of the code unless necessary

    public QueenFitness(int boardSize) {
        this.boardSize = boardSize;
    }

    private int boardSize;
    private long limit = 1000000L; // Using long instead of int
    private double bestResult = 0.0;

    public double getFitness(Integer[] solution, List<? extends Integer[]> list) {
        if (limit == 0) {
            System.out.println("Number of fitness evaluations is exceeded!");
            System.out.println("___Your final best result = " + bestResult + "!___");
            System.exit(0);
        }
        limit--;
        // Start evaluations
        double result = boardSize * (boardSize + 1)/2;
        double base = result; // maximum number of conflicts
        for (int i = 0; i < solution.length; i++) {
            if (solution[i] == 0) {
                if(boardSize == 1) result=0; else
                {
                    result-= (1 +boardSize)/4.5;
                }
            } else {

                for (int j = i + 1; j < solution.length; j++) {
                    if ((solution[i] == solution[j]) || (solution[j]!=0 &&Math.abs(solution[j] - solution[i]) == j - i)) {
                        result--;
                    }
                }
            }
        }
        result = Math.max(result, 0);
        result = Math.pow(result/base, boardSize/Math.log(boardSize+1));
        if (bestResult < result) {
            bestResult = result;
        }
        return  result;
//        return result/base;
    }

    public boolean isNatural() {
        return true;
    }
}
