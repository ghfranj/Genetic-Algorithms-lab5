package org.example;

import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.factories.AbstractCandidateFactory;
import org.uncommons.watchmaker.framework.operators.AbstractCrossover;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class QueenCrossover extends AbstractCrossover<Integer[]> {
    private final int boardSize;
    private final Probability crossoverProbability;

    public QueenCrossover(int boardSize, Probability crossoverProbability) {
        super(2); // Binary crossover (crossover of two parents).
        this.boardSize = boardSize;
        this.crossoverProbability = crossoverProbability;
    }

    @Override
    protected List<Integer[]> mate(Integer[] parent1, Integer[] parent2, int numberOfCrossoverPoints, Random random) {
        List<Integer[]> offspring = new ArrayList<>(2); // Two offspring from each crossover.

        Integer[] child1 = new Integer[boardSize];
        Integer[] child2 = new Integer[boardSize];

        // Perform crossover if the crossover probability is met.
        if (random.nextDouble() < crossoverProbability.doubleValue()) {
            // Choose crossover points (columns) randomly.
            int crossoverPoint1 = random.nextInt(boardSize);
            int crossoverPoint2 = random.nextInt(boardSize);

            // Ensure crossoverPoint2 > crossoverPoint1.
            if (crossoverPoint1 > crossoverPoint2) {
                int temp = crossoverPoint1;
                crossoverPoint1 = crossoverPoint2;
                crossoverPoint2 = temp;
            }

            // Copy genes from parents to children outside the crossover points.
            for (int i = 0; i < boardSize; i++) {
                if (i < crossoverPoint1 || i > crossoverPoint2) {
                    child1[i] = parent1[i];
                    child2[i] = parent2[i];
                }
            }

            // Fill in remaining genes from the other parent.
            int index1 = crossoverPoint1;
            int index2 = crossoverPoint1;
            for (int i = crossoverPoint1; i <= crossoverPoint2; i++) {
                while (child1[index1] != null) {
                    index1 = (index1 + 1) % boardSize; // Wrap around if needed.
                }
                while (child2[index2] != null) {
                    index2 = (index2 + 1) % boardSize; // Wrap around if needed.
                }
                child1[index1] = parent2[i];
                child2[index2] = parent1[i];
            }
        } else {
            // If the crossover probability is not met, offspring are identical to parents.
            child1 = parent1.clone();
            child2 = parent2.clone();
        }

        offspring.add(child1);
        offspring.add(child2);

        return offspring;
    }
}
