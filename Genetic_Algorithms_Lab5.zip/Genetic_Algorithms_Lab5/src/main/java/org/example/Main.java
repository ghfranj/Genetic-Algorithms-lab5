package org.example;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import org.example.QueenPlacementGA;

import java.util.Arrays;

public class Main extends Application {
    private static final int BOARD_SIZE = 512;
    private static final int POPULATION_SIZE = 100;
    private static final int GENERATIONS = 4500;
    private static final double MUTATION_PROBABILITY = 0.5;
    private static final double CROSSOVER_PROBABILITY = 0.2;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Get the best solution from the genetic algorithm
        Integer[] bestSolution = QueenPlacementGA.getBestSolution(BOARD_SIZE, POPULATION_SIZE,
                GENERATIONS, MUTATION_PROBABILITY, CROSSOVER_PROBABILITY);

        // Visualize the best solution on a chessboard
        visualizeSolution(bestSolution);
    }

    private void visualizeSolution(Integer[] bestSolution) {
        // Create a new stage for visualization
        Stage boardStage = new Stage();
        boardStage.setTitle("Queen Placement Visualization");

        // Create a grid pane to represent the chessboard
        GridPane boardPane = new GridPane();
        boardPane.setPadding(new Insets(10));
        boardPane.setHgap(5);
        boardPane.setVgap(5);

        // Add cells to the grid pane based on the best solution
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                Rectangle cell = new Rectangle(50, 50); // Create a square cell
                cell.setStroke(Color.BLACK); // Add black border
                cell.setFill((row + col) % 2 == 0 ? Color.LIGHTGRAY : Color.WHITE); // Alternate cell colors
                boardPane.add(cell, col, row); // Add cell to the grid pane

                // If the queen is placed on this cell, draw a queen icon
                if (bestSolution[row] == col + 1) {
                    Rectangle queen = new Rectangle(50, 50, Color.RED); // Queen icon
                    queen.setStroke(Color.BLACK); // Add black border
                    GridPane.setMargin(queen, new Insets(0)); // Add margin for proper alignment
                    boardPane.add(queen, col, row); // Add queen icon to the cell
                }
            }
        }

        // Set the scene with the grid pane on the stage
        Scene boardScene = new Scene(boardPane, 50 * BOARD_SIZE, 50 * BOARD_SIZE);
        boardStage.setScene(boardScene);
        boardStage.show();
    }
}
