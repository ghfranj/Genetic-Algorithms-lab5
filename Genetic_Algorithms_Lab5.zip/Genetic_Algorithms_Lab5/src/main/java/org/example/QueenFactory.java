package org.example;

import org.uncommons.watchmaker.framework.factories.AbstractCandidateFactory;
import java.util.Random;

public class QueenFactory extends AbstractCandidateFactory<Integer[]> {
    private final int boardSize;

    public QueenFactory(int boardSize) {
        this.boardSize = boardSize;
    }

    @Override
    public Integer[] generateRandomCandidate(Random random) {
        Integer[] candidate = new Integer[boardSize];
        for (int i = 0; i < boardSize; i++) {
            // Generate a random column index for placing the queen
            candidate[i] = random.nextInt((boardSize+1));
        }
        return candidate;
    }
}
