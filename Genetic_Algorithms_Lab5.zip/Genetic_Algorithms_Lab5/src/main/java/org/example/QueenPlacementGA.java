package org.example;

import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.*;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.selection.TournamentSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class QueenPlacementGA {
    public Integer[] bestSolution;

//    public static void main(String[] args) {
//        getBestSolution();
//    }

    public static Integer[] getBestSolution(int boardSize, int populationSize, int generations,
                                            double mutationProb, double crossoverProb
    ) {
//        int boardSize = 8; // Dimension of the problem
//        int populationSize = 10; // Size of population
//        int generations = 100; // Number of generations
//        double mutationProb = 0.05;
//        double crossoverProb = 0.05;
        Random random = new Random(); // Random number generator

        CandidateFactory<Integer[]> factory = new QueenFactory(boardSize);

        ArrayList<EvolutionaryOperator<Integer[]>> operators = new ArrayList<>();
        operators.add(new QueenCrossover(boardSize, new Probability(crossoverProb)));
        operators.add(new QueenMutation(boardSize, new Probability(mutationProb)));
        EvolutionPipeline<Integer[]> pipeline = new EvolutionPipeline<>(operators);

        SelectionStrategy<Object> selection = new TournamentSelection(new Probability(0.9));

        FitnessEvaluator<Integer[]> evaluator = new QueenFitness(boardSize);

        EvolutionEngine<Integer[]> algorithm = new SteadyStateEvolutionEngine<>(
                factory, pipeline, evaluator, selection, populationSize, false, random);

        QueenPlacementGA queenPlacementGA = new QueenPlacementGA();

        algorithm.addEvolutionObserver(new EvolutionObserver() {
            public void populationUpdate(PopulationData populationData) {
                double bestFit = populationData.getBestCandidateFitness();
                System.out.println("Generation " + populationData.getGenerationNumber() + ": " + bestFit);
                Integer[] currentBestCandidate = (Integer[]) populationData.getBestCandidate();
//                System.out.println("\tBest solution = " + Arrays.toString(currentBestCandidate));
                System.out.println("\tPop size = " + populationData.getPopulationSize());

                // Update the bestSolution if a new best solution is found
                if (queenPlacementGA.bestSolution == null || bestFit > evaluator.getFitness(queenPlacementGA.bestSolution, null)) {
                    queenPlacementGA.bestSolution = Arrays.copyOf(currentBestCandidate, currentBestCandidate.length);
                }
            }
        });

        TerminationCondition terminate = new GenerationCount(generations);

        algorithm.evolve(populationSize, 1, terminate);

        System.out.println("Best solution found: " + Arrays.toString(queenPlacementGA.bestSolution));
        return queenPlacementGA.bestSolution;
    }
}
